package org.xzc.learn.fasterxml;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;
import java.util.List;

/**
 * Created by xzchaoo on 2016/4/11 0011.
 */
@JsonInclude(JsonInclude.Include.ALWAYS)
public class User {
	private Integer id;
	@JsonProperty(value = "um")
	private String username;
	private Date birthday;

	private double money;

	private List<String> comments;

	public User() {
	}

	public User(Integer id, String username, Date birthday, double money, List<String> comments) {
		this.id = id;
		this.username = username;
		this.birthday = birthday;
		this.money = money;
		this.comments = comments;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public List<String> getComments() {
		return comments;
	}

	public void setComments(List<String> comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "User{" +
			"id=" + id +
			", username='" + username + '\'' +
			", birthday=" + birthday +
			", money=" + money +
			", comments=" + comments +
			'}';
	}
}
