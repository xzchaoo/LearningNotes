package org.xzc.learn.fasterxml;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by xzchaoo on 2016/4/11 0011.
 */
public class Paper implements Serializable{
	private Integer id;
	private String title;
	private Date createdAt;
	private String content;


	public Paper() {
	}

	public Paper(Integer id, String title, Date createdAt, String content) {
		this.id = id;
		this.title = title;
		this.createdAt = createdAt;
		this.content = content;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
