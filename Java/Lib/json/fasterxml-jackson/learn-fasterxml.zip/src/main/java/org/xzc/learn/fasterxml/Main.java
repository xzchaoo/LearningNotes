package org.xzc.learn.fasterxml;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by xzchaoo on 2016/4/11 0011.
 */
public class Main {
	private static final Logger log = Logger.getLogger(Main.class);

	public static void main(String[] args) throws IOException {
		if (log.isTraceEnabled()) log.trace("启动了");

		ObjectMapper om = new ObjectMapper();

		//包含非空
		om.setSerializationInclusion(JsonInclude.Include.NON_NULL);

		om.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, true);

		//om.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));

		User user = new User(1, null, new DateTime(1970, 1, 1, 0, 0).toDate(), 1077, null);
		String s = om.writeValueAsString(user);
		log.info(s);

		user = om.readValue(s, User.class);
		log.info(user);


		List<User> userList = new ArrayList<>();
		for (int i = 0; i < 10; ++i) {
			user = new User(i + 1, "xzc" + i, new DateTime(1994, 5, 20 + i, 0, 0).toDate(), 10 + i, Arrays.asList("c1", "c2"));
			userList.add(user);
		}
		s = om.writeValueAsString(userList);
		log.info(s);

		userList = om.readValue(s, new TypeReference<List<User>>() {
		});
		System.out.println(userList);


		if (log.isTraceEnabled()) log.trace("结束了");
	}
}
